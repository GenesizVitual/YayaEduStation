CREATE TRIGGER update_pembelian_pengeluaran_update
AFTER UPDATE ON tbl_pembelian_barang
FOR EACH ROW
  BEGIN
	update tbl_pengeluaran_barang set id_gudang= new.id_gudang where tbl_pengeluaran_barang.id_pembelian = old.id;
END;
